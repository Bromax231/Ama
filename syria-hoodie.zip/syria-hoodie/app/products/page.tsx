'use client'
import Image from 'next/image'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import Layout from '@/components/layout'
import { useLanguage } from '@/contexts/LanguageContext'

const products = ['syria-hoodie', 'syria-tshirt']

export default function ProductsPage() {
  const { t } = useLanguage()

  return (
    <Layout>
      <div className="container mx-auto py-16">
        <h1 className="text-4xl font-bold text-center mb-12">{t('products.title')}</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <div key={product} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <Image
                src={`/${product}-front.png`}
                alt={t(`products.${product}.name`)}
                width={500}
                height={500}
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h2 className="text-xl font-bold mb-2">{t(`products.${product}.name`)}</h2>
                <p className="text-gray-600 mb-4">{t(`products.${product}.description`)}</p>
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold">${t(`products.${product}.price`)}</span>
                  <Button asChild>
                    <Link href={`/products/${product}`}>{t('products.viewDetails')}</Link>
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  )
}

