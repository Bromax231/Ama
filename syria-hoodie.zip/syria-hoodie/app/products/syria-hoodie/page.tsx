import ProductDisplay from '@/components/product-display'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Syria Limited Edition Hoodie | AMA',
  description: 'Premium quality black hoodie with custom Syria-themed artwork. Limited edition design commemorating 08.12.2024.',
}

export default function SyriaHoodiePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-100 to-white">
      <ProductDisplay />
    </div>
  )
}

