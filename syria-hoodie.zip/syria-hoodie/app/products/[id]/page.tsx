'use client'

import { useState } from 'react'
import Image from 'next/image'
import { useParams } from 'next/navigation'
import { Button } from '@/components/ui/button'
import Layout from '@/components/layout'
import { useLanguage } from '@/contexts/LanguageContext'

export default function ProductPage() {
  const { id } = useParams()
  const { t } = useLanguage()
  const [currentView, setCurrentView] = useState<'front' | 'back'>('front')
  const [size, setSize] = useState('')
  const [quantity, setQuantity] = useState(1)

  const handleBuyNow = () => {
    const message = encodeURIComponent(`I want to order the ${t(`products.${id}.name`)}:
Size: ${size}
Quantity: ${quantity}
Total: $${(parseFloat(t(`products.${id}.price`)) * quantity).toFixed(2)}`)
    window.open(`https://wa.me/905058058254?text=${message}`, '_blank')
  }

  return (
    <Layout>
      <div className="container mx-auto py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="space-y-4">
            <div className="relative aspect-square bg-white rounded-xl overflow-hidden shadow-lg">
              <Image
                src={`/${id}-${currentView}.png`}
                alt={`${t(`products.${id}.name`)} - ${currentView} view`}
                fill
                className="object-contain p-4"
              />
            </div>
            <div className="flex gap-4 justify-center">
              <Button
                variant="outline"
                onClick={() => setCurrentView('front')}
                className={`relative w-20 h-20 p-0 ${currentView === 'front' ? 'ring-2 ring-green-600' : ''}`}
              >
                <Image
                  src={`/${id}-front.png`}
                  alt="Front view"
                  fill
                  className="object-cover"
                />
              </Button>
              <Button
                variant="outline"
                onClick={() => setCurrentView('back')}
                className={`relative w-20 h-20 p-0 ${currentView === 'back' ? 'ring-2 ring-green-600' : ''}`}
              >
                <Image
                  src={`/${id}-back.png`}
                  alt="Back view"
                  fill
                  className="object-cover"
                />
              </Button>
            </div>
          </div>

          <div className="space-y-6">
            <h1 className="text-3xl font-bold">{t(`products.${id}.name`)}</h1>
            <p className="text-xl text-gray-600">{t(`products.${id}.description`)}</p>
            <div className="text-2xl font-bold">${t(`products.${id}.price`)}</div>

            <div className="space-y-4">
              <div>
                <label htmlFor="size" className="block text-sm font-medium text-gray-700">
                  {t('products.size')}
                </label>
                <select
                  id="size"
                  value={size}
                  onChange={(e) => setSize(e.target.value)}
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm rounded-md"
                >
                  <option value="">{t('products.selectSize')}</option>
                  {['S', 'M', 'L', 'XL'].map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="quantity" className="block text-sm font-medium text-gray-700">
                  {t('products.quantity')}
                </label>
                <select
                  id="quantity"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm rounded-md"
                >
                  {[1, 2, 3, 4, 5].map((q) => (
                    <option key={q} value={q}>{q}</option>
                  ))}
                </select>
              </div>
            </div>

            <Button onClick={handleBuyNow} size="lg" className="w-full">
              {t('products.buyNow')}
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  )
}

