'use client'
import Image from 'next/image'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import Layout from '@/components/layout'
import { useLanguage } from '@/contexts/LanguageContext'

export default function Home() {
  const { t } = useLanguage()

  return (
    <Layout>
      <div className="bg-gradient-to-r from-green-400 to-blue-500 text-white py-20">
        <div className="container mx-auto text-center">
          <h1 className="text-5xl font-bold mb-4">{t('home.hero.title')}</h1>
          <p className="text-xl mb-8">{t('home.hero.subtitle')}</p>
          <Button asChild size="lg">
            <Link href="/products">{t('home.hero.cta')}</Link>
          </Button>
        </div>
      </div>

      <div className="container mx-auto py-16">
        <h2 className="text-3xl font-bold text-center mb-12">{t('home.featured.title')}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {['syria-hoodie', 'syria-tshirt'].map((product) => (
            <div key={product} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <Image
                src={`/${product}-front.png`}
                alt={t(`products.${product}.name`)}
                width={500}
                height={500}
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{t(`products.${product}.name`)}</h3>
                <p className="text-gray-600 mb-4">{t(`products.${product}.description`)}</p>
                <Button asChild>
                  <Link href={`/products/${product}`}>{t('home.featured.viewProduct')}</Link>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  )
}

