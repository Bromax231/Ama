import { LanguageProvider } from '@/contexts/LanguageContext'
import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'AMA - Syria Support Clothing',
  description: 'Support Syria with stylish and meaningful clothing',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        <LanguageProvider>
          {children}
        </LanguageProvider>
      </body>
    </html>
  )
}

