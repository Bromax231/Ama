'use client'
import Layout from '@/components/layout'
import { useLanguage } from '@/contexts/LanguageContext'

export default function AboutPage() {
  const { t } = useLanguage()

  return (
    <Layout>
      <div className="container mx-auto py-16">
        <h1 className="text-4xl font-bold text-center mb-8">{t('about.title')}</h1>
        <div className="max-w-2xl mx-auto">
          <p className="text-lg mb-4">{t('about.content1')}</p>
          <p className="text-lg mb-4">{t('about.content2')}</p>
          <p className="text-lg">{t('about.content3')}</p>
        </div>
      </div>
    </Layout>
  )
}

