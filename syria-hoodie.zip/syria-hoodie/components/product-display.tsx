'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ShoppingCart, ChevronLeft, ChevronRight, MessageCircle } from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'

interface ProductProps {
  id: string
  name: string
  subtitle: string
  price: number
  originalPrice: number
  images: {
    front: string
    back: string
  }
}

const products: ProductProps[] = [
  {
    id: 'syria-hoodie',
    name: 'Syria Limited Edition Hoodie',
    subtitle: 'سوريا الحرة',
    price: 16,
    originalPrice: 19,
    images: {
      front: '/syria-hoodie-black-front.png',
      back: '/syria-hoodie-black-back.png'
    }
  },
  {
    id: 'syria-tshirt',
    name: 'Syria Freedom T-Shirt',
    subtitle: 'الحرية لسوريا',
    price: 12,
    originalPrice: 15,
    images: {
      front: '/syria-tshirt-white-front.png',
      back: '/syria-tshirt-white-back.png'
    }
  }
]

function ProductCard({ product }: { product: ProductProps }) {
  const [currentView, setCurrentView] = useState<'front' | 'back'>('front')
  const [size, setSize] = useState('')
  const [quantity, setQuantity] = useState(1)
  const { language, t } = useLanguage()

  const changeView = (direction: 'next' | 'prev') => {
    setCurrentView(direction === 'next' ? 'back' : 'front')
  }

  const handleAddToCart = () => {
    alert('Added to cart!')
  }

  const handleBuyNow = () => {
    const message = encodeURIComponent(`I want to order the ${product.name}:
Size: ${size}
Quantity: ${quantity}
Total: $${(product.price * quantity).toFixed(2)}`)
    window.open(`https://wa.me/905058058254?text=${message}`, '_blank')
  }

  return (
    <Card className="p-6 space-y-6 bg-white shadow-lg border-green-200 border-2">
      <div className="space-y-4">
        <div className="relative aspect-square w-full bg-white rounded-xl overflow-hidden shadow-lg">
          <Image
            src={currentView === 'front' ? product.images.front : product.images.back}
            alt={`${product.name} - ${currentView} view`}
            fill
            className="object-contain p-4"
          />
          <div className="absolute inset-0 flex items-center justify-between p-4">
            <Button variant="ghost" size="icon" onClick={() => changeView('prev')}>
              <ChevronLeft className="h-8 w-8" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => changeView('next')}>
              <ChevronRight className="h-8 w-8" />
            </Button>
          </div>
        </div>
        <div className="flex gap-4 justify-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentView('front')}
            className={`relative aspect-square w-20 h-20 p-0 overflow-hidden ${currentView === 'front' ? 'ring-2 ring-green-600' : ''}`}
          >
            <Image
              src={product.images.front}
              alt="Front view"
              fill
              className="object-cover"
            />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentView('back')}
            className={`relative aspect-square w-20 h-20 p-0 overflow-hidden ${currentView === 'back' ? 'ring-2 ring-green-600' : ''}`}
          >
            <Image
              src={product.images.back}
              alt="Back view"
              fill
              className="object-cover"
            />
          </Button>
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-2">{product.name}</h2>
        <p className="text-xl text-gray-600 mb-4">{product.subtitle}</p>
        <div className="flex items-center gap-4">
          <Badge variant="secondary" className="text-lg px-3 py-1">{t('product.limitedEdition')}</Badge>
          <Badge variant="outline" className="text-lg px-3 py-1">08.12.2024</Badge>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-3xl font-bold">${product.price.toFixed(2)}</span>
            <span className="text-xl text-gray-500 line-through">${product.originalPrice.toFixed(2)}</span>
          </div>
          <Badge variant="secondary" className="text-lg px-3 py-1">{t('product.inStock')}</Badge>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <select 
            className="w-full p-3 border rounded-md text-lg"
            value={size}
            onChange={(e) => setSize(e.target.value)}
          >
            <option value="">{t('product.size')}</option>
            <option value="S">Small</option>
            <option value="M">Medium</option>
            <option value="L">Large</option>
            <option value="XL">X-Large</option>
          </select>
          <select 
            className="w-full p-3 border rounded-md text-lg"
            value={quantity}
            onChange={(e) => setQuantity(Number(e.target.value))}
          >
            {[1, 2, 3, 4, 5].map((num) => (
              <option key={num} value={num}>{num}</option>
            ))}
          </select>
        </div>

        <div className="flex gap-4">
          <Button className="flex-1 text-lg py-6 bg-green-600 hover:bg-green-700" onClick={handleAddToCart}>
            <ShoppingCart className="mr-2 h-5 w-5" /> {t('product.addToCart')}
          </Button>
          <Button variant="outline" className="flex-1 text-lg py-6" onClick={handleBuyNow}>
            <MessageCircle className="mr-2 h-5 w-5" /> {t('product.buyNow')}
          </Button>
        </div>
      </div>
    </Card>
  )
}

export default function ProductDisplay() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  )
}

