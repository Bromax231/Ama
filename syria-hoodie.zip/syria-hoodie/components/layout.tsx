import Link from 'next/link'
import Image from 'next/image'
import { useLanguage } from '@/contexts/LanguageContext'

export default function Layout({ children }: { children: React.ReactNode }) {
  const { language, setLanguage, t } = useLanguage()

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <header className="bg-black text-white p-4 sticky top-0 z-50">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="flex items-center space-x-2">
            <Image src="/ama-logo.png" alt="AMA Logo" width={40} height={40} />
            <span className="text-2xl font-bold">AMA</span>
          </Link>
          <nav>
            <ul className="flex space-x-6">
              <li><Link href="/products" className="hover:text-green-400 transition-colors">{t('nav.products')}</Link></li>
              <li><Link href="/about" className="hover:text-green-400 transition-colors">{t('nav.about')}</Link></li>
              <li><Link href="/contact" className="hover:text-green-400 transition-colors">{t('nav.contact')}</Link></li>
              <li>
                <button onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')} className="hover:text-green-400 transition-colors">
                  {language === 'en' ? 'عربي' : 'English'}
                </button>
              </li>
            </ul>
          </nav>
        </div>
      </header>
      <main className="flex-grow">{children}</main>
      <footer className="bg-black text-white py-6">
        <div className="container mx-auto text-center">
          <p>&copy; 2023 AMA. {t('footer.rights')}</p>
        </div>
      </footer>
    </div>
  )
}

